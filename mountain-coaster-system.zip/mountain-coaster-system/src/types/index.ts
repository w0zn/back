export interface CoasterCreationParams {
    staff: number;
    dailyCustomers: number;
    trackLength: number;
    operatingHours: string;
  }

  export interface CoasterUpdateParams {
    staff: number;
    dailyCustomers: number;
    operatingHours: string;
  }

  export interface WagonCreationParams {
    seats: number;
    speed: number;
  }