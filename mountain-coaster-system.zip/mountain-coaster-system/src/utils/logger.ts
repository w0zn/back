import winston from 'winston';
import path from 'path';
import config from '../config';

const logFilePath = process.env.NODE_ENV === 'production' 
  ? path.join(__dirname, '../../logs/production') // Oddzielny folder dla produkcji
  : path.join(__dirname, '../../logs/development'); // Oddzielny folder dla deweloperów

const logger = winston.createLogger({
  level: config.LOG_LEVEL,
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: path.join(logFilePath, 'error.log'), level: 'error' }),
    new winston.transports.File({ filename: path.join(logFilePath, 'warn.log'), level: 'warn' }),
    new winston.transports.File({ filename: path.join(logFilePath, 'info.log') }),
    // Dodanie transportów dla console.error, console.warn i console.log
    new winston.transports.Console({ level: 'error', format: winston.format.simple() }),
    new winston.transports.Console({ level: 'warn', format: winston.format.simple() }),
    new winston.transports.Console({ level: 'info', format: winston.format.simple() })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
} else {
  // W produkcji dodajemy tylko transporty dla warn i error
  logger.add(new winston.transports.Console({
    level: 'warn',
    format: winston.format.simple()
  }));
  logger.add(new winston.transports.Console({
    level: 'error',
    format: winston.format.simple()
  }));
}

export default logger;
