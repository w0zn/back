import devConfig from './dev';
   import prodConfig from './prod';

   interface Config {
     PORT: number;
     REDIS_HOST: string;
     REDIS_PORT: number;
     LOG_LEVEL: string;
   }

   const config: Config = process.env.NODE_ENV === 'production' ? prodConfig : devConfig;

   export default config;