export default {
    PORT: 3050,
    REDIS_HOST: 'localhost',
    REDIS_PORT: 6379,
    LOG_LEVEL: 'debug'
  };