    import express, { Request, Response } from 'express';
    import coasterService from '../services/coasterService';
    import { CoasterCreationParams, CoasterUpdateParams } from '../types';

    const router = express.Router();

    router.post('/', async (req: Request<{}, {}, CoasterCreationParams>, res: Response) => {
      try {
        const { staff, dailyCustomers, trackLength, operatingHours } = req.body;
        const coaster = await coasterService.addCoaster(staff, dailyCustomers, trackLength, operatingHours);
        res.status(201).json(coaster);
      } catch (error) {
        res.status(400).json({ message: (error as any).message });
      }
    });

    router.put('/:coasterId', async (req: Request<{ coasterId: string }, {}, CoasterUpdateParams>, res: Response) => {
      try {
        const { coasterId } = req.params;
        const { staff, dailyCustomers, operatingHours } = req.body;
        const updatedCoaster = await coasterService.updateCoaster(coasterId, staff, dailyCustomers, operatingHours);
        res.json(updatedCoaster);
      } catch (error) {
        res.status(400).json({ message: (error as any).message });
      }
    });

    export default router;
