import express, { Request, Response } from 'express';
    import wagonService from '../services/wagonService';
    import { WagonCreationParams } from '../types';

    const router = express.Router();

    router.post('/:coasterId/wagons', async (req: Request<{ coasterId: string }, {}, WagonCreationParams>, res: Response) => {
      try {
        const { coasterId } = req.params;
        const { seats, speed } = req.body;
        const wagon = await wagonService.addWagon(coasterId, seats, speed);
        res.status(201).json(wagon);
      } catch (error) {
        res.status(400).json({ message: (error as any).message });
      }
    });

    router.delete('/:coasterId/wagons/:wagonId', async (req: Request<{ coasterId: string, wagonId: string }>, res: Response) => {
      try {
        const { coasterId, wagonId } = req.params;
        await wagonService.removeWagon(coasterId, wagonId);
        res.status(204).send();
      } catch (error) {
        res.status(400).json({ message: (error as any).message });
      }
    });

    export default router;
