    import express from 'express';
    import config from './config';
    import logger from './utils/logger';
    import coasterRoutes from './routes/coasters';
    import wagonRoutes from './routes/wagons';
    import { setupSwagger } from './swagger';

    const app = express();

    app.use(express.json());
    
    setupSwagger(app);

    // Routes
    app.use('/api/coasters', coasterRoutes);
    app.use('/api/coasters', wagonRoutes);

    // Error handling middleware
    app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
      logger.error(err.stack);
      res.status(500).send('Something went wrong!');
    });

    const PORT = config.PORT;

    app.listen(PORT, () => {
      logger.info(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
    });