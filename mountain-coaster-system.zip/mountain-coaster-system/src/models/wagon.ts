export class Wagon {
    id: string;
    seats: number;
    speed: number;

    constructor(id: string, seats: number, speed: number) {
      this.id = id;
      this.seats = seats;
      this.speed = speed;
    }
  }