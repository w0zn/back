import { Wagon } from './wagon'

   export class Coaster {
     id: string;
     staff: number;
     dailyCustomers: number;
     trackLength: number;
     operatingHours: string;
     wagons: Wagon[] = [];

     constructor(id: string, staff: number, dailyCustomers: number, trackLength: number, operatingHours: string, wagons: Wagon[] = []) {
       this.id = id;
       this.staff = staff;
       this.dailyCustomers = dailyCustomers;
       this.trackLength = trackLength;
       this.operatingHours = operatingHours;
       this.wagons = wagons;
     }

     addWagon(wagon: Wagon): void {
       this.wagons.push(wagon);
     }

     removeWagon(wagonId: string): void {
       this.wagons = this.wagons.filter(wagon => wagon.id !== wagonId);
     }

     updateDetails(staff: number, dailyCustomers: number, operatingHours: string): void {
       this.staff = staff;
       this.dailyCustomers = dailyCustomers;
       this.operatingHours = operatingHours;
     }
   }
