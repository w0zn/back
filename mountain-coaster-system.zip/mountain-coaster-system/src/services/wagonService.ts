import { Wagon } from '../models/wagon';
    import redisService from './redisService';
    import logger from '../utils/logger';

    class WagonService {
      async addWagon(coasterId: string, seats: number, speed: number): Promise<Wagon> {
        const coaster = await redisService.getCoaster(coasterId);
        if (!coaster) {
          throw new Error('Coaster not found');
        }
        const id = await redisService.generateId('wagon');

        const wagon = new Wagon(id, seats, speed);
        logger.info(`Wagon: ${JSON.stringify(wagon)}`);

        coaster.addWagon(wagon);

        logger.info(`coaster: ${JSON.stringify(coaster)}`);
        
        await redisService.saveCoaster(coaster);
        logger.info(`New wagon added to coaster ${coasterId}: ${id}`);
        return wagon;
      }

      async removeWagon(coasterId: string, wagonId: string): Promise<void> {
        const coaster = await redisService.getCoaster(coasterId);
        if (!coaster) {
          throw new Error('Coaster not found');
        }
        coaster.removeWagon(wagonId);
        await redisService.saveCoaster(coaster);
        logger.info(`Wagon removed from coaster ${coasterId}: ${wagonId}`);
      }
    }

    export default new WagonService();