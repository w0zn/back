import redis from 'redis'; // Ensure this import is correct
import config from '../config';
import logger from '../utils/logger';
import { Coaster } from '../models/coaster';
import { createClient } from 'redis';

export class RedisService {
  private client: redis.RedisClientType;
  private requiredStaffPerCoaster: number = 1; // 1 staff per coaster
  private requiredStaffPerWagon: number = 2; // 2 staff per wagon
  private dailyCustomerCapacity: number; // Liczba klientów, których kolejka powinna obsłużyć w ciągu dnia
  private isCentralNode: boolean = false; // Flaga wskazująca, czy węzeł jest centralny
  private connectedCoasters: Set<string> = new Set(); // Zbiór podłączonych kolejek

  constructor() {
    // this.client = redis.createClient({
    //   url: `redis://${config.REDIS_HOST}:${config.REDIS_PORT}`
    // });
    this.client = createClient({
        url: 'redis://localhost:6379'
    });
    this.client.on('error', (err) => console.error('Redis Client Error', err));
    this.client.connect();

    this.client.on('error', (error: any) => {
      logger.error(`Redis error: ${error}`);
    });

    this.dailyCustomerCapacity = 0; // Inicjalizacja na 0 lub można ustawić domyślną wartość
    this.initializeNode();
    this.startStatisticsMonitoring(); // Start monitoring statistics
  }

  private initializeNode(): void {
    // Logika do inicjalizacji węzła, np. sprawdzenie, czy jest podłączony do sieci
    // Ustalanie, czy węzeł jest centralny
    if (this.connectedCoasters.size > 1) {
      this.isCentralNode = true; // Ustawienie węzła jako centralnego
    }
  }

  private startStatisticsMonitoring(): void {
    setInterval(async () => {
        try {
            await this.displayStatistics(); // Call the displayStatistics method periodically
        } catch (error) {
            logger.error(`Error in displayStatistics: ${error}`);
        }
        }, 10000); // Update every 10 seconds (adjust as needed)
    }

  public connectCoaster(coasterId: string): void {
    this.connectedCoasters.add(coasterId);
    logger.info(`Coaster connected: ${coasterId}`);
    this.initializeNode(); // Check if the node should be central
}

  public disconnectCoaster(coasterId: string): void {
    this.connectedCoasters.delete(coasterId);
    this.initializeNode(); // Sprawdzenie, czy węzeł powinien być centralny
  }

  public async synchronizeData(): Promise<void> {
    if (this.isCentralNode) {
      // Logika do synchronizacji danych między węzłami
      // Może obejmować przesyłanie danych o kolejkach, wagonach, pracownikach itp.
      // Użycie asynchronicznych operacji, aby nie blokować systemu
      try {
        // Przykład synchronizacji danych
        const connectedCoasters = Array.from(this.connectedCoasters);
        for (const coasterId of connectedCoasters) {
          // Synchronizacja danych dla każdego podłączonego węzła
          await this.syncWithCoaster(coasterId);
        }
      } catch (error) {
        logger.error(`Błąd synchronizacji danych: ${error}`);
      }
    }
  }

  private async syncWithCoaster(coasterId: string): Promise<void> {
    try {
        // Fetch the current coaster data
        const coaster = await this.getCoaster(coasterId);
        if (!coaster) {
            logger.warn(`Coaster ${coasterId} not found for synchronization.`);
            return;
        }

        // Fetch the wagons associated with the coaster
        const wagons = await this.client.sMembers(`coaster:${coasterId}:wagons`);
        logger.info(`Synchronizing wagons for coaster ${coasterId}: ${wagons}`);

        // Fetch the staff associated with the coaster
        const staff = await this.client.sMembers('staff');
        logger.info(`Synchronizing staff for coaster ${coasterId}: ${staff}`);

        // Here you can implement the logic to send this data to the specified coaster node
        // For example, you might send an HTTP request to the coaster's API endpoint
        // This is a placeholder for the actual synchronization logic
        // await sendDataToCoasterNode(coasterId, { coaster, wagons, staff });

        logger.info(`Synchronization completed for coaster ${coasterId}.`);
    } catch (error) {
        logger.error(`Error synchronizing with coaster ${coasterId}: ${error}`);
    }
  }

  public async operateIndependently(): Promise<void> {
    logger.info('Operating independently: Node is not connected to the network.');

    // Local storage for coasters, wagons, and staff
    const localCoasters: Map<string, Coaster> = new Map(); // Store coasters locally
    const localWagons: Map<string, string[]> = new Map(); // Store wagons by coasterId
    const localStaff: Set<string> = new Set(); // Store staff IDs

    // Example: Simulate local operations
    // You can implement logic to add, remove, or update coasters, wagons, and staff
    // For demonstration, let's assume we have some local operations

    // Adding a coaster locally
    const coasterId = 'coaster-1'; // Example coaster ID
    const newCoaster = new Coaster(coasterId, 5, 1000, 200, '09:00-17:00'); // Example coaster
    localCoasters.set(coasterId, newCoaster);
    logger.info(`Added coaster locally: ${JSON.stringify(newCoaster)}`);

    // Adding wagons locally
    const wagonIds = ['wagon-1', 'wagon-2'];
    localWagons.set(coasterId, wagonIds);
    logger.info(`Added wagons locally for coaster ${coasterId}: ${wagonIds}`);

    // Adding staff locally
    localStaff.add('staff-1');
    localStaff.add('staff-2');
    logger.info(`Added staff locally: ${Array.from(localStaff)}`);

    // Example: Perform operations on local data
    // You can implement logic to check availability, perform updates, etc.
    // For example, checking if there are enough staff for the local coaster
    const requiredStaff = 1 + (wagonIds.length * 2); // 1 staff per coaster + 2 per wagon
    if (localStaff.size < requiredStaff) {
        logger.warn(`Not enough staff for coaster ${coasterId}. Required: ${requiredStaff}, Available: ${localStaff.size}`);
    } else {
        logger.info(`Sufficient staff for coaster ${coasterId}.`);
    }

    // You can also implement logic to periodically save local data to a file or database
    // This is a placeholder for actual local storage logic
    // await saveLocalDataToFile(localCoasters, localWagons, localStaff);
  }

  async generateId(prefix: string): Promise<string> {
    const id = await this.client.incr(`${prefix}Id`);
    return `${prefix}-${id}`;
  }

  async saveCoaster(coaster: Coaster): Promise<void> {
    await this.client.set(`coaster:${coaster.id}`, JSON.stringify(coaster));
  }

  async getCoaster(coasterId: string): Promise<Coaster | null> {
    const coasterData = await this.client.get(`coaster:${coasterId}`);
    if (!coasterData) return null;

    const parsedData = JSON.parse(coasterData);
    // Create an instance of Coaster using the parsed data
    return new Coaster(parsedData.id, parsedData.staff, parsedData.dailyCustomers, parsedData.trackLength, parsedData.operatingHours, parsedData.wagons);
  }

  async incrementKey(key: string) {
    if (!this.client.isOpen) {
      await this.client.connect();
    }
    return await this.client.incr(key);
  }

  async registerCoaster(coaster: Coaster): Promise<void> {
    await this.client.set(`coaster:${coaster.id}`, JSON.stringify(coaster));
  }

  public async updateCoaster(coasterId: string, updatedCoaster: Coaster): Promise<void> {
    await this.client.set(`coaster:${coasterId}`, JSON.stringify(updatedCoaster));
    // Natychmiastowe wprowadzenie zmian lokalnie
    // Synchronizacja z innymi węzłami w tle
    this.synchronizeData(); // Wywołanie synchronizacji w tle
  }

  async deleteCoaster(coasterId: string): Promise<void> {
    await this.client.del(`coaster:${coasterId}`);
  }

  async registerWagon(coasterId: string, wagonId: string): Promise<void> {
    await this.client.sAdd(`coaster:${coasterId}:wagons`, wagonId);
  }

  async removeWagon(coasterId: string, wagonId: string): Promise<void> {
    await this.client.sRem(`coaster:${coasterId}:wagons`, wagonId);
  }

  async setOperatingHours(coasterId: string, from: string, to: string): Promise<void> {
    await this.client.hSet(`coaster:${coasterId}:hours`, {
      from: from,
      to: to
    });
  }

  async checkWagonReturn(wagonId: string, coasterId: string): Promise<boolean> {
    const currentTime = new Date();
    const operatingHours = await this.client.hGetAll(`coaster:${coasterId}:hours`);
    const endTime = new Date();
    endTime.setHours(parseInt(operatingHours.to), 0, 0, 0);

    // Check if the wagon can return before the end of operating hours
    return currentTime < endTime;
  }

  async checkWagonBreak(wagonId: string): Promise<boolean> {
    // Logic to check if the wagon has had a 5-minute break
    // This would require additional state management
    return true; // Placeholder
  }

  async registerStaff(staffId: string): Promise<void> {
    await this.client.sAdd('staff', staffId);
  }

  async removeStaff(staffId: string): Promise<void> {
    await this.client.sRem('staff', staffId);
  }

  async checkStaffAvailability(coasterId: string): Promise<string> {
    const staffCount = await this.client.sCard('staff');
    const wagonCount = await this.client.sCard(`coaster:${coasterId}:wagons`);
    const requiredStaff = this.requiredStaffPerCoaster + (wagonCount * this.requiredStaffPerWagon);
    
    if (staffCount < requiredStaff) {
      const missingStaff = requiredStaff - staffCount;
      return `Brakuje ${missingStaff} pracowników do obsługi kolejki górskiej i wagonów.`;
    } else if (staffCount > requiredStaff) {
      const excessStaff = staffCount - requiredStaff;
      return `Jest za dużo pracowników o ${excessStaff} więcej niż wymagane.`;
    }
    return 'Wystarczająca liczba pracowników do obsługi kolejki górskiej i wagonów.';
  }

  async setDailyCustomerCapacity(capacity: number): Promise<void> {
    this.dailyCustomerCapacity = capacity;
  }

  async checkCustomerCapacity(coasterId: string): Promise<string> {
    const wagonCount = await this.client.sCard(`coaster:${coasterId}:wagons`);
    const staffCount = await this.client.sCard('staff');
    
    const requiredWagons = Math.ceil(this.dailyCustomerCapacity / 100); // Zakładając, że jeden wagon obsługuje 100 klientów
    const requiredStaff = this.requiredStaffPerCoaster + (requiredWagons * this.requiredStaffPerWagon);

    if (wagonCount < requiredWagons || staffCount < requiredStaff) {
      const missingWagons = Math.max(0, requiredWagons - wagonCount);
      const missingStaff = Math.max(0, requiredStaff - staffCount);
      return `Brakuje ${missingWagons} wagonów i ${missingStaff} pracowników do obsługi ${this.dailyCustomerCapacity} klientów.`;
    } else if (wagonCount > requiredWagons * 2 || staffCount > requiredStaff * 2) {
      const excessWagons = wagonCount - requiredWagons * 2;
      const excessStaff = staffCount - requiredStaff * 2;
      return `Jest za dużo wagonów o ${excessWagons} i pracowników o ${excessStaff} więcej niż wymagane.`;
    }
    return 'Wystarczająca liczba wagonów i pracowników do obsługi klientów.';
  }

  public async displayStatistics(): Promise<void> {
    const connectedCoasters = Array.from(this.connectedCoasters);
    for (const coasterId of connectedCoasters) {
      const wagonCount = await this.client.sCard(`coaster:${coasterId}:wagons`);
      const staffCount = await this.client.sCard('staff');
      const operatingHours = await this.client.hGetAll(`coaster:${coasterId}:hours`);
      const dailyCustomers = this.dailyCustomerCapacity; // Zakładamy, że to jest liczba klientów dziennie

      const requiredWagons = Math.ceil(dailyCustomers / 100); // Zakładając, że jeden wagon obsługuje 100 klientów
      const requiredStaff = this.requiredStaffPerCoaster + (requiredWagons * this.requiredStaffPerWagon);

      let status = 'OK';
      let problems = [];

      if (wagonCount < requiredWagons) {
        const missingWagons = requiredWagons - wagonCount;
        problems.push(`Brakuje ${missingWagons} wagonów`);
      }
      if (staffCount < requiredStaff) {
        const missingStaff = requiredStaff - staffCount;
        problems.push(`Brakuje ${missingStaff} pracowników`);
      }

      // Wyświetlanie statystyk za pomocą loggera
      logger.info(`[Kolejka ${coasterId}]`);
      logger.info(`Godziny działania: ${operatingHours.from} - ${operatingHours.to}`);
      logger.info(`Liczba wagonów: ${wagonCount}/${requiredWagons}`);
      logger.info(`Dostępny personel: ${staffCount}/${requiredStaff}`);
      logger.info(`Klienci dziennie: ${dailyCustomers}`);
      if (problems.length > 0) {
        logger.warn(`Problem: ${problems.join(', ')}`);
      } else {
        logger.info(`Status: ${status}`);
      }
      logger.info('--------------------------');
    }
  }
}

export default new RedisService();
