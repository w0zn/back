import { Coaster } from '../models/coaster';
    import redisService from './redisService';
    import logger from '../utils/logger';

    class CoasterService {
      async addCoaster(staff: number, dailyCustomers: number, trackLength: number, operatingHours: string): Promise<Coaster> {
        const id = await redisService.generateId('coaster');
        const coaster = new Coaster(id, staff, dailyCustomers, trackLength, operatingHours);
        await redisService.saveCoaster(coaster);
        logger.info(`New coaster added: ${id}`);
        return coaster;
      }

      async updateCoaster(coasterId: string, staff: number, dailyCustomers: number, operatingHours: string): Promise<Coaster> {
        const coaster = await redisService.getCoaster(coasterId);
        if (!coaster) {
          throw new Error('Coaster not found');
        }
        coaster.updateDetails(staff, dailyCustomers, operatingHours);
        await redisService.saveCoaster(coaster);
        logger.info(`Coaster updated: ${coasterId}`);
        return coaster;
      }
    }

    export default new CoasterService();